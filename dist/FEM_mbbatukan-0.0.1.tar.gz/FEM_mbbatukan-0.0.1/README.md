# FEM

This reposity contains finite element method (FEM) files wrtiten in Python. 
 
## 1. Truss solver
Mainly inspired by the following textbook by Kattan, P. I. (2010). MATLAB guide to finite elements: an interactive approach. Springer Science & Business Media.
